package pubsub;

public interface Broker {

    <T> void subscribe(Topic<T> topic, Subscriber<T> subscriber);

    <T> void unsubscribe(Topic<T> topic, Subscriber<T> subscriber);

    <T> void publish(Topic<T> topic, Object publisher, T data);
}
