package pubsub;

import java.time.Instant;

public final class Message<T> {

    private final Object publisher;
    private final Topic<T> topic;
    private final T data;
    private final Instant timestamp;

    public Message(Object publisher, Topic<T> topic, T data) {
        this.publisher = publisher;
        this.topic = topic;
        this.data = data;
        this.timestamp = Instant.now();
    }

    public Object getPublisher() {
        return publisher;
    }

    public Topic<T> getTopic() {
        return topic;
    }

    public T getData() {
        return data;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "Message{topic=" + topic + ", data=" + data + ", publisher=" + publisher
                + ", timestamp=" + timestamp + '}';
    }
}
