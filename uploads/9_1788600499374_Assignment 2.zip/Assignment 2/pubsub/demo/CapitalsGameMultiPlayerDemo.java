package pubsub.demo;

import pubsub.Broker;
import pubsub.Message;
import pubsub.PubSubBroker;
import pubsub.Subscriber;
import pubsub.Topic;

import java.util.HashMap;
import java.util.Map;

public final class CapitalsGameMultiPlayerDemo {

    public record AnswerEvent(String player, String country, String givenCapital, boolean correct) {
    }

    static final class CapitalsGameModel {

        static final Topic<AnswerEvent> ANSWER_SUBMITTED = new Topic<>("capitals.answerSubmitted");

        private final Broker broker = PubSubBroker.getInstance();
        private final String playerName;

        CapitalsGameModel(String playerName) {
            this.playerName = playerName;
        }

        void submitAnswer(String country, String givenCapital, String actualCapital) {
            boolean correct = givenCapital.equalsIgnoreCase(actualCapital);
            broker.publish(ANSWER_SUBMITTED, this, new AnswerEvent(playerName, country, givenCapital, correct));
        }
    }

    static final class Leaderboard implements Subscriber<AnswerEvent> {

        private final Map<String, Integer> scores = new HashMap<>();

        @Override
        public void onMessage(Message<AnswerEvent> message) {
            AnswerEvent event = message.getData();
            if (event.correct()) {
                scores.merge(event.player(), 1, Integer::sum);
            }
            System.out.println("[Leaderboard] " + event.player() + " -> " + event.country()
                    + " (" + (event.correct() ? "correct" : "wrong") + "), score now "
                    + scores.getOrDefault(event.player(), 0));
        }
    }

    public static void main(String[] args) {
        Broker broker = PubSubBroker.getInstance();

        CapitalsGameModel player1 = new CapitalsGameModel("Kalvin");
        CapitalsGameModel player2 = new CapitalsGameModel("Sam");

        Leaderboard leaderboard = new Leaderboard();
        broker.subscribe(CapitalsGameModel.ANSWER_SUBMITTED, leaderboard);

        Subscriber<AnswerEvent> spectator = message ->
                System.out.println("[Spectator] watching: " + message.getData());
        broker.subscribe(CapitalsGameModel.ANSWER_SUBMITTED, spectator);

        player1.submitAnswer("France", "Paris", "Paris");
        player2.submitAnswer("Japan", "Tokyo", "Tokyo");

        broker.unsubscribe(CapitalsGameModel.ANSWER_SUBMITTED, spectator);
        System.out.println("-- spectator left, leaderboard keeps going --");

        player1.submitAnswer("Australia", "Sydney", "Canberra");
        player2.submitAnswer("Egypt", "Cairo", "Cairo");
    }
}
