package pubsub.demo;

import pubsub.Broker;
import pubsub.PubSubBroker;
import pubsub.Topic;

public final class CapitalsGamePubSubDemo {

    public record AnswerResult(String country, String givenCapital, boolean correct) {
    }

    static final class CapitalsGameModel {

        static final Topic<AnswerResult> ANSWER_SUBMITTED = new Topic<>("capitals.answerSubmitted");

        private final Broker broker = PubSubBroker.getInstance();
        private int score = 0;

        void submitAnswer(String country, String givenCapital, String actualCapital) {
            boolean correct = givenCapital.equalsIgnoreCase(actualCapital);
            if (correct) score++;
            broker.publish(ANSWER_SUBMITTED, this, new AnswerResult(country, givenCapital, correct));
        }

        int getScore() {
            return score;
        }
    }

    public static void main(String[] args) {
        Broker broker = PubSubBroker.getInstance();
        CapitalsGameModel model = new CapitalsGameModel();

        broker.subscribe(CapitalsGameModel.ANSWER_SUBMITTED, msg -> {
            AnswerResult result = msg.getData();
            System.out.println("[ScoreLabel] " + (result.correct() ? "Correct!" : "Wrong.")
                    + " Score is now " + model.getScore());
        });

        broker.subscribe(CapitalsGameModel.ANSWER_SUBMITTED, msg -> {
            AnswerResult result = msg.getData();
            System.out.println("[Logger] " + result.country() + " -> " + result.givenCapital());
        });

        model.submitAnswer("France", "Paris", "Paris");
        model.submitAnswer("Australia", "Sydney", "Canberra");
    }
}
