package pubsub;

@FunctionalInterface
public interface Subscriber<T> {
    void onMessage(Message<T> message);
}
