package pubsub;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class PubSubBroker implements Broker {

    private static final PubSubBroker INSTANCE = new PubSubBroker();

    private final Map<Topic<?>, List<Subscriber<?>>> subscribers = new ConcurrentHashMap<>();

    private PubSubBroker() {
    }

    public static PubSubBroker getInstance() {
        return INSTANCE;
    }

    @Override
    public <T> void subscribe(Topic<T> topic, Subscriber<T> subscriber) {
        subscribers
                .computeIfAbsent(topic, t -> new CopyOnWriteArrayList<>())
                .add(subscriber);
    }

    @Override
    public <T> void unsubscribe(Topic<T> topic, Subscriber<T> subscriber) {
        List<Subscriber<?>> list = subscribers.get(topic);
        if (list != null) {
            list.remove(subscriber);
            if (list.isEmpty()) {
                subscribers.remove(topic, list);
            }
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> void publish(Topic<T> topic, Object publisher, T data) {
        List<Subscriber<?>> list = subscribers.get(topic);
        if (list == null || list.isEmpty()) {
            return;
        }

        Message<T> message = new Message<>(publisher, topic, data);
        for (Subscriber<?> raw : list) {
            Subscriber<T> subscriber = (Subscriber<T>) raw;
            subscriber.onMessage(message);
        }
    }
}
