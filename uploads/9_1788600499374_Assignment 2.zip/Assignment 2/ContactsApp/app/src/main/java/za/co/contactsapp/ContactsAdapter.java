package za.co.contactsapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactViewHolder> {

    public interface Listener {
        void onEditClicked(Contact contact);
    }

    private static final int[] AVATAR_COLORS = {
            0xFF2196F3, 0xFF4CAF50, 0xFFFF9800, 0xFFE91E63,
            0xFF9C27B0, 0xFF00BCD4, 0xFFFFC107, 0xFF795548
    };

    private final Context context;
    private List<Contact> contacts;
    private final Listener listener;
    private int expandedPosition = -1;

    public ContactsAdapter(Context context, List<Contact> contacts, Listener listener) {
        this.context = context;
        this.contacts = contacts;
        this.listener = listener;
    }

    public void updateContacts(List<Contact> newContacts) {
        contacts = newContacts;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_contact_card, parent, false);
        return new ContactViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
        Contact contact = contacts.get(position);

        holder.name.setText(contact.getName());
        holder.number.setText(contact.getNumber());

        boolean hasCustomPhoto = false;
        if (contact.getAvatarFileName() != null) {
            File file = new File(context.getFilesDir(), contact.getAvatarFileName());
            if (file.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                holder.avatar.setImageBitmap(bitmap);
                holder.avatar.setPadding(0, 0, 0, 0);
                holder.avatar.setBackgroundColor(0x00000000);
                hasCustomPhoto = true;
            }
        }
        if (!hasCustomPhoto) {
            int color = AVATAR_COLORS[Math.abs(contact.getId().hashCode()) % AVATAR_COLORS.length];
            holder.avatar.setBackgroundColor(color);
            holder.avatar.setImageResource(R.drawable.ic_default_avatar);
            int padding = (int) (24 * context.getResources().getDisplayMetrics().density);
            holder.avatar.setPadding(padding, padding, padding, padding);
        }

        boolean expanded = position == expandedPosition;
        holder.actionsRow.setVisibility(expanded ? View.VISIBLE : View.GONE);

        holder.itemView.setOnClickListener(v -> {
            int previous = expandedPosition;
            expandedPosition = expanded ? -1 : position;
            notifyItemChanged(previous);
            notifyItemChanged(position);
        });

        holder.editButton.setOnClickListener(v -> listener.onEditClicked(contact));

        holder.messageButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + contact.getNumber()));
            context.startActivity(intent);
        });

        holder.dialButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + contact.getNumber()));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    static class ContactViewHolder extends RecyclerView.ViewHolder {

        ImageView avatar;
        TextView name;
        TextView number;
        LinearLayout actionsRow;
        ImageButton editButton;
        ImageButton messageButton;
        ImageButton dialButton;

        ContactViewHolder(View itemView) {
            super(itemView);
            avatar = itemView.findViewById(R.id.imgAvatar);
            name = itemView.findViewById(R.id.txtName);
            number = itemView.findViewById(R.id.txtNumber);
            actionsRow = itemView.findViewById(R.id.actionsRow);
            editButton = itemView.findViewById(R.id.btnEdit);
            messageButton = itemView.findViewById(R.id.btnMessage);
            dialButton = itemView.findViewById(R.id.btnDial);
        }
    }
}
