package za.co.contactsapp;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import za.co.contactsapp.pubsub.Broker;
import za.co.contactsapp.pubsub.PubSubBroker;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ContactStore {

    private static final String FILE_NAME = "contacts.json";

    private static ContactStore instance;

    private final Context context;
    private final List<Contact> contacts = new ArrayList<>();
    private final Broker broker = PubSubBroker.getInstance();

    private ContactStore(Context context) {
        this.context = context.getApplicationContext();
        load();
    }

    public static synchronized ContactStore getInstance(Context context) {
        if (instance == null) {
            instance = new ContactStore(context);
        }
        return instance;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public Contact getContact(String id) {
        for (Contact contact : contacts) {
            if (contact.getId().equals(id)) {
                return contact;
            }
        }
        return null;
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
        save();
        broker.publish(Topics.CONTACT_CHANGED, this, contact);
    }

    public void updateContact(Contact updated) {
        for (int i = 0; i < contacts.size(); i++) {
            if (contacts.get(i).getId().equals(updated.getId())) {
                contacts.set(i, updated);
                break;
            }
        }
        save();
        broker.publish(Topics.CONTACT_CHANGED, this, updated);
    }

    private void load() {
        try {
            FileInputStream fis = context.openFileInput(FILE_NAME);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
            reader.close();

            JSONArray array = new JSONArray(builder.toString());
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String avatar = obj.isNull("avatar") ? null : obj.getString("avatar");
                contacts.add(new Contact(
                        obj.getString("id"),
                        obj.getString("name"),
                        obj.getString("number"),
                        avatar));
            }
        } catch (Exception e) {
            seedContacts();
            save();
        }
    }

    private void seedContacts() {
        contacts.add(new Contact(UUID.randomUUID().toString(), "Thabo Nkosi", "082 111 2233", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Sarah Adams", "083 222 3344", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Liam Botha", "071 333 4455", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Aisha Patel", "084 444 5566", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Michael van Wyk", "082 555 6677", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Nomvula Dlamini", "073 666 7788", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "David Reyneke", "079 777 8899", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Zanele Khumalo", "082 888 9900", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Pieter de Klerk", "083 999 0011", null));
        contacts.add(new Contact(UUID.randomUUID().toString(), "Amanda Cele", "071 000 1122", null));
    }

    private void save() {
        try {
            JSONArray array = new JSONArray();
            for (Contact contact : contacts) {
                JSONObject obj = new JSONObject();
                obj.put("id", contact.getId());
                obj.put("name", contact.getName());
                obj.put("number", contact.getNumber());
                obj.put("avatar", contact.getAvatarFileName());
                array.put(obj);
            }
            FileOutputStream fos = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            fos.write(array.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
