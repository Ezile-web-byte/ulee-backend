package za.co.contactsapp.pubsub;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The one broker that every publisher and subscriber in the app shares.
 *
 * Implemented as a classic singleton rather than a static class on
 * purpose: because it implements {@link Broker}, it can still be passed
 * around and mocked out in tests (a static class with static methods
 * cannot implement an interface, so it can't be substituted). The
 * singleton just guarantees there is exactly one shared instance, which is
 * the one thing the spec actually requires.
 *
 * Internally topics map to their list of subscribers. The list type
 * (CopyOnWriteArrayList) is chosen so that a subscriber can safely
 * unsubscribe itself from inside its own onMessage callback, and so that
 * publish() is safe to call concurrently from multiple threads — both
 * realistic scenarios once this is wired into an Android UI plus
 * background work.
 *
 * publish()'s unchecked cast is the one deliberate, contained exception to
 * full type safety: the map has to be raw (Topic<?> -> Subscriber<?>) to
 * hold every topic's subscribers together, but every subscriber under a
 * given Topic<T> was only ever added via subscribe(Topic<T>, Subscriber<T>),
 * so the cast back to Subscriber<T> when publishing to that same topic is
 * always safe.
 */
public final class PubSubBroker implements Broker {

    private static final PubSubBroker INSTANCE = new PubSubBroker();

    private final Map<Topic<?>, List<Subscriber<?>>> subscribers = new ConcurrentHashMap<>();

    private PubSubBroker() {
        // Private constructor: the only way to get a reference is
        // getInstance(), so there is exactly one broker for the app.
    }

    public static PubSubBroker getInstance() {
        return INSTANCE;
    }

    @Override
    public <T> void subscribe(Topic<T> topic, Subscriber<T> subscriber) {
        subscribers
                .computeIfAbsent(topic, t -> new CopyOnWriteArrayList<>())
                .add(subscriber);
    }

    @Override
    public <T> void unsubscribe(Topic<T> topic, Subscriber<T> subscriber) {
        List<Subscriber<?>> list = subscribers.get(topic);
        if (list != null) {
            list.remove(subscriber);
            if (list.isEmpty()) {
                subscribers.remove(topic, list);
            }
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> void publish(Topic<T> topic, Object publisher, T data) {
        List<Subscriber<?>> list = subscribers.get(topic);
        if (list == null || list.isEmpty()) {
            return;
        }

        Message<T> message = new Message<>(publisher, topic, data);
        for (Subscriber<?> raw : list) {
            Subscriber<T> subscriber = (Subscriber<T>) raw;
            subscriber.onMessage(message);
        }
    }
}
