package za.co.contactsapp;

public class Contact {

    private String id;
    private String name;
    private String number;
    private String avatarFileName;

    public Contact(String id, String name, String number, String avatarFileName) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.avatarFileName = avatarFileName;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAvatarFileName() {
        return avatarFileName;
    }

    public void setAvatarFileName(String avatarFileName) {
        this.avatarFileName = avatarFileName;
    }
}
