package za.co.contactsapp.pubsub;

/**
 * The contract for a message broker.
 *
 * Publishers and subscribers should depend on this interface, not on any
 * concrete implementation (Dependency Inversion). That's what makes it
 * possible to unit test a class that publishes/subscribes by handing it a
 * mock Broker, and to swap the delivery mechanism later (e.g. an
 * asynchronous, thread-pool-backed Broker) without touching a single
 * publisher or subscriber.
 *
 * The interface is deliberately small (Interface Segregation) — three
 * methods, nothing a publisher-only or subscriber-only class is forced to
 * implement but never uses.
 */
public interface Broker {

    /**
     * Register interest in a topic. The same subscriber instance may be
     * registered for several topics, and several subscribers may register
     * for the same topic.
     */
    <T> void subscribe(Topic<T> topic, Subscriber<T> subscriber);

    /**
     * Stop receiving messages about a topic. Safe to call even if the
     * subscriber was never registered for that topic.
     */
    <T> void unsubscribe(Topic<T> topic, Subscriber<T> subscriber);

    /**
     * Send a message about a topic. Every subscriber currently registered
     * for that topic receives it; if nobody is registered, the message is
     * simply dropped. The publisher never sees who (if anyone) received it.
     */
    <T> void publish(Topic<T> topic, Object publisher, T data);
}
