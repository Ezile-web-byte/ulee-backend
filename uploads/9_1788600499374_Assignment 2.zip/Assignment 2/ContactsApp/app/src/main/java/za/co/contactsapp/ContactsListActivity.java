package za.co.contactsapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.UUID;

import za.co.contactsapp.pubsub.Broker;
import za.co.contactsapp.pubsub.PubSubBroker;
import za.co.contactsapp.pubsub.Subscriber;

public class ContactsListActivity extends AppCompatActivity implements ContactsAdapter.Listener {

    private final Broker broker = PubSubBroker.getInstance();

    private ContactStore store;
    private ContactsAdapter adapter;
    private Subscriber<Contact> contactChangedSubscriber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_list);

        store = ContactStore.getInstance(this);

        RecyclerView recyclerView = findViewById(R.id.recyclerContacts);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        adapter = new ContactsAdapter(this, store.getContacts(), this);
        recyclerView.setAdapter(adapter);

        contactChangedSubscriber = message -> adapter.updateContacts(store.getContacts());
        broker.subscribe(Topics.CONTACT_CHANGED, contactChangedSubscriber);

        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> {
            Contact newContact = new Contact(UUID.randomUUID().toString(), "New Contact", "", null);
            store.addContact(newContact);

            Intent intent = new Intent(ContactsListActivity.this, ContactActivity.class);
            intent.putExtra("contact_id", newContact.getId());
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        broker.unsubscribe(Topics.CONTACT_CHANGED, contactChangedSubscriber);
    }

    @Override
    public void onEditClicked(Contact contact) {
        Intent intent = new Intent(this, ContactActivity.class);
        intent.putExtra("contact_id", contact.getId());
        startActivity(intent);
    }
}
