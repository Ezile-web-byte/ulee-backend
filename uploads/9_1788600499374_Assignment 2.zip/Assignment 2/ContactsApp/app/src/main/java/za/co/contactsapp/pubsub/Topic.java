package za.co.contactsapp.pubsub;

import java.util.Objects;

/**
 * A strongly-typed identifier for a category of messages.
 *
 * The generic parameter T fixes the type of data that will be carried by
 * any {@link Message} published on this Topic, so publishers and
 * subscribers agree on a payload type without either one needing a
 * reference to (or any knowledge of) the other's concrete class.
 *
 * Two Topic instances are considered equal if they share the same name,
 * so the same logical topic (e.g. "a") can be referenced independently
 * by any number of publishers and subscribers.
 */
public final class Topic<T> {

    private final String name;

    public Topic(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Topic name cannot be null or blank");
        }
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Topic<?> other)) return false;
        return name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "Topic[" + name + "]";
    }
}
