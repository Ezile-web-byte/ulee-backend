package za.co.contactsapp.pubsub;

/**
 * Anything that wants to receive messages about a Topic implements this
 * (or, more usually, just provides a lambda). Being a functional interface
 * is what lets subscriber code stay a one-liner at the call site instead of
 * requiring a bespoke listener class per topic, the way per-property
 * listener interfaces tend to.
 */
@FunctionalInterface
public interface Subscriber<T> {
    void onMessage(Message<T> message);
}
