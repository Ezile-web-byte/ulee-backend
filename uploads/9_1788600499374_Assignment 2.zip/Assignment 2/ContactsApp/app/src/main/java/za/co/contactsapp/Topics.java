package za.co.contactsapp;

import za.co.contactsapp.pubsub.Topic;

public final class Topics {

    public static final Topic<Contact> CONTACT_CHANGED = new Topic<>("contact.changed");

    private Topics() {
    }
}
