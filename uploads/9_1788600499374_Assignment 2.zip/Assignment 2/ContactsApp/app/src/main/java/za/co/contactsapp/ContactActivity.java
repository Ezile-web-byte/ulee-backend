package za.co.contactsapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class ContactActivity extends AppCompatActivity {

    private ContactStore store;
    private Contact contact;

    private ImageView imgAvatar;
    private EditText editName;
    private EditText editNumber;

    private final ActivityResultLauncher<String> imagePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    saveAvatarImage(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        store = ContactStore.getInstance(this);
        String contactId = getIntent().getStringExtra("contact_id");
        contact = store.getContact(contactId);

        imgAvatar = findViewById(R.id.imgAvatarLarge);
        editName = findViewById(R.id.editName);
        editNumber = findViewById(R.id.editNumber);

        editName.setText(contact.getName());
        editNumber.setText(contact.getNumber());
        loadAvatar();

        imgAvatar.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        FloatingActionButton fabDial = findViewById(R.id.fabDial);
        fabDial.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + editNumber.getText().toString()));
            startActivity(intent);
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        contact.setName(editName.getText().toString());
        contact.setNumber(editNumber.getText().toString());
        store.updateContact(contact);
    }

    private void loadAvatar() {
        if (contact.getAvatarFileName() != null) {
            File file = new File(getFilesDir(), contact.getAvatarFileName());
            if (file.exists()) {
                imgAvatar.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                imgAvatar.setPadding(0, 0, 0, 0);
                return;
            }
        }
        imgAvatar.setImageResource(R.drawable.ic_default_avatar);
    }

    private void saveAvatarImage(Uri uri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            inputStream.close();

            String fileName = "avatar_" + contact.getId() + ".jpg";
            FileOutputStream fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();

            contact.setAvatarFileName(fileName);
            imgAvatar.setImageBitmap(bitmap);
            imgAvatar.setPadding(0, 0, 0, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
